from config.database import db
from config.settings import MONGO_URI

__all__ = ["MONGO_URI","db"]


