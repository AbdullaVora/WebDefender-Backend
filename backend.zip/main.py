from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from routers.userRoute import router as user_router
from routers.tools.subdomainRoute import router as subdomain_router
from routers.tools.sqlRoute import router as sql_router
import os
import uvicorn

# Initialize FastAPI app
app = FastAPI(
    title="Your API",
    root_path=""
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # Allow frontend origin
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Include routers
app.include_router(user_router, prefix="/api/auth")  # User authentication routes
app.include_router(subdomain_router, prefix="/api/tools")  # Tools-related routes
app.include_router(sql_router, prefix="/api/tools")  # Tools-related routes

# Root endpoint
@app.get("/")
async def home():
    return "Server is running successfully"

# Run the app using Uvicorn
if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")  # Default to 127.0.0.1 if HOST is not set
    port = int(os.environ.get("PORT", 8002))  # Default to 8080 if PORT is not set
    uvicorn.run("main:app", host=host, port=port, reload=True)

